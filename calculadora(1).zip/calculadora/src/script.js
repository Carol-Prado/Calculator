var firstValue = parseFloat(prompt("Type a number :"))

var secondValue = parseFloat(prompt ("Type the second number:"))


var operation = prompt("Type 1 for division, Type 2 for mutiplication, Type 3 for addition, Type 3 for subtraction: ")


if(operation==1){
  var result = firstValue/secondValue
  document.write("<h2>"+firstValue+"/"+secondValue +"="+result+"</h2>")
}

else if(operation==2){
  var result = firstValue*secondValue
  document.write("<h2>"+firstValue+"X"+ secondValue+"="+result+"</h2>")
}

else if(operation==3){
  var result = firstValue+secondValue
  document.write("<h2>"+firstValue+"+"+ secondValue+"="+result+"</h2>")
}
else if(operation==4){
  var result= firstValue-secondValue
  document.write("<h2>"+firstValue+"-"+ secondValue+"="+result+"</h2>")
}
else{
  document.write("<h2>Invalid Option</h2>")
}
//Escrevendo JavaScript na tela -> document.write()//
/*
* This program was made in a bootcamp session
*
*/